import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { FeedPage } from './feed';

@NgModule({
  declarations: [
    FeedPage,
  ],
  imports: [
    IonicPageModule.forChild(FeedPage),
  ],
})
export class FeedPageModule {
   public lista_filmes = new Array<any>();

}
(click)="irParaDestino(livro)"> ionViewDidLoad() {
  this.movieProvider.getPopularMovies().subscribe(
  data => {
  const response = (data as any);
  const objeto_retorno = JSON.parse(response._body);
  this.lista_filmes = objeto_retorno.results;
  console.log(objeto_retorno);
  }, error => {
  console.log(error);
  }
  )
 